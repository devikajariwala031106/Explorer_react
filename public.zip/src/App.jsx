import { BrowserRouter, Routes, Route } from "react-router-dom"
import Navbar from "./components/Navbar"
import TailwindPage from "./pages/TailwindPage"
import MuiPage from "./pages/MuiPage"
import AntdPage from "./pages/AntdPage"

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<TailwindPage />} />
        <Route path="/mui" element={<MuiPage />} />
        <Route path="/antd" element={<AntdPage />} />
      </Routes>
    </BrowserRouter>
  )
}
