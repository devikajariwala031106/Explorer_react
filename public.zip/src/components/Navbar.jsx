import { Link, useLocation } from "react-router-dom"

export default function Navbar() {
    const { pathname } = useLocation()

    const linkClass = path =>
        `relative px-5 py-2 text-sm font-semibold transition-all ${pathname === path
            ? "text-white"
            : "text-white/70 hover:text-white"
        }`

    return (
        <div className="sticky top-0 z-50">
            <div className="px-10 py-5 bg-gradient-to-r from-indigo-700 via-purple-700 to-fuchsia-700 shadow-2xl">
                <div className="flex items-center justify-between">
                    <h1 className="text-2xl font-extrabold tracking-wide text-white">
                        Three Framework UI
                    </h1>

                    <div className="flex gap-6">
                        {[
                            { path: "/", label: "Tailwind" },
                            { path: "/mui", label: "Material UI" },
                            { path: "/antd", label: "Ant Design" }
                        ].map(item => (
                            <Link key={item.path} to={item.path} className={linkClass(item.path)}>
                                {item.label}
                                {pathname === item.path && (
                                    <span className="absolute -bottom-2 left-0 right-0 h-[3px] rounded-full bg-white" />
                                )}
                            </Link>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}
