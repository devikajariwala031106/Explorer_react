import { Container, Grid, Card, CardContent, Typography } from "@mui/material"

export default function MuiPage() {
    return (
        <Container maxWidth="lg" sx={{ mt: 8, mb: 8 }}>
            <Typography
                variant="h4"
                sx={{ fontWeight: 800, mb: 1, color: "white" }}
            >
                Learning Dashboard
            </Typography>

            <Typography sx={{ color: "#94a3b8", mb: 5 }}>
                Track your enrolled programs and progress
            </Typography>

            <Grid container spacing={4}>
                {["React Development", "Node.js Backend", "UI / UX Design"].map(course => (
                    <Grid item xs={12} md={4} key={course}>
                        <Card
                            sx={{
                                background: "rgba(15,23,42,0.75)",
                                backdropFilter: "blur(12px)",
                                borderRadius: "20px",
                                border: "1px solid rgba(255,255,255,0.08)",
                                color: "white",
                                transition: "0.3s",
                                "&:hover": {
                                    transform: "translateY(-6px)",
                                    boxShadow: "0 25px 50px rgba(0,0,0,0.6)"
                                }
                            }}
                        >
                            <CardContent>
                                <Typography variant="h6">{course}</Typography>
                                <Typography sx={{ color: "#94a3b8", mt: 1 }}>
                                    Status: Active
                                </Typography>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
        </Container>
    )
}
