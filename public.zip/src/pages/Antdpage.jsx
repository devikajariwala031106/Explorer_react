import { Row, Col, Card, Statistic } from "antd"

export default function AntdPage() {
    return (
        <div className="page-wrapper">
            <h1 className="section-title">Business Analytics</h1>
            <p className="section-subtitle">
                Sales, customers and profit overview
            </p>

            <Row gutter={24}>
                {[
                    { title: "Orders", value: 320 },
                    { title: "Customers", value: 890 },
                    { title: "Profit", value: 56000, prefix: "₹" }
                ].map(item => (
                    <Col span={8} key={item.title}>
                        <Card
                            style={{
                                background: "rgba(15,23,42,0.75)",
                                backdropFilter: "blur(12px)",
                                borderRadius: 20,
                                border: "1px solid rgba(255,255,255,0.08)"
                            }}
                        >
                            <Statistic
                                title={<span style={{ color: "#94a3b8" }}>{item.title}</span>}
                                value={item.value}
                                prefix={item.prefix}
                                valueStyle={{ color: "white", fontWeight: 700 }}
                            />
                        </Card>
                    </Col>
                ))}
            </Row>
        </div>
    )
}
