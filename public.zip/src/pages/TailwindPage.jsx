export default function TailwindPage() {
    return (
        <div className="min-h-screen px-12 py-16 bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950">
            <div className="max-w-6xl mx-auto">

                <h1 className="text-5xl font-extrabold text-white">
                    Performance Overview
                </h1>

                <p className="text-lg text-slate-400 mt-4 max-w-2xl">
                    Real-time system metrics and growth analysis
                </p>

                <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-10">

                    <div className="rounded-2xl border border-indigo-500/30 bg-slate-900/70 backdrop-blur p-8 shadow-xl hover:shadow-indigo-500/20 transition">
                        <p className="text-slate-400 text-sm">Active Users</p>
                        <h2 className="text-4xl font-bold text-indigo-400 mt-3">
                            1,245
                        </h2>
                    </div>

                    <div className="rounded-2xl border border-emerald-500/30 bg-slate-900/70 backdrop-blur p-8 shadow-xl hover:shadow-emerald-500/20 transition">
                        <p className="text-slate-400 text-sm">Monthly Revenue</p>
                        <h2 className="text-4xl font-bold text-emerald-400 mt-3">
                            ₹84,000
                        </h2>
                    </div>

                    <div className="rounded-2xl border border-pink-500/30 bg-slate-900/70 backdrop-blur p-8 shadow-xl hover:shadow-pink-500/20 transition">
                        <p className="text-slate-400 text-sm">Growth Rate</p>
                        <h2 className="text-4xl font-bold text-pink-400 mt-3">
                            18%
                        </h2>
                    </div>

                </div>
            </div>
        </div>
    )
}
